# IR 전문가 캡슐

등록 ID: brain_ir_expert

투자 검토 질문, 사업 논리·근거·수치, 정부지원 공고 대응, 한국어 문장·시각 검수에 특화한 CARI 캡슐입니다.

## 사용

CARI 채팅에서 IR 전문가 캡슐을 선택하고 실제 회사 브리프·자료와 필요한 산출물을 요청합니다. “제공한 사실만 써서 투자검토용 IR 패키지를 한컴·PDF·피그마로 만들어줘”는 HWPX/PDF/PPTX와 Figma 가져오기 자료가 담긴 ZIP을 생성합니다. 일반 IR 검토는 채팅으로 답하고 IR PPT 단일 요청은 기존 PPT 제작/편집 경로를 사용합니다. 회사 자료가 없으면 필요한 질문과 확인 가능한 분석부터 진행합니다.

파일의 모든 숫자가 자동으로 참이라는 뜻은 아닙니다. 실제값과 전망·가정을 구분하고 근거표와 추가 확인 목록을 검토하세요. Figma importer는 오프라인 플러그인이며 실행·저장하기 전 .fig 완성본이 아닙니다. HWPX는 바이너리 HWP가 아니며 신규 작성과 공식 양식 보존 편집은 다릅니다.

## 포함과 범위

공개 출처 230개 중 실제 접근한 197개를 바탕으로 만든 짧은 요약, 작성 절차, 행동평가 사례를 포함합니다. 투자·선정 성공을 보장하지 않습니다. 영상 URL 발견, 자막 확보·판독, 영상 화면 시청은 별도로 집계합니다. 원문·영상·전체 자막·사용자 PDF·타사 비공개 수치·이미지·인증 정보는 포함하지 않습니다. 이 자료를 가져와도 모델 가중치가 학습되지는 않습니다.

## 개발 실행

node server/scripts/build-ir-corpus.mjs
python3 server/scripts/ir-corpus-status.py
./server/node_modules/.bin/tsc -p server/tsconfig.json
node --test server/dist/brains/ir-expert.test.js server/dist/ai/providers/bedrock.provider.test.js
node server/scripts/export-ir-expert.mjs

실제 모델·전체 페이지·한컴/PowerPoint/Figma의 독립 검토와 운영 배포 상태는 docs/guides/ir-expert.md의 최신 검증 기록을 확인하세요.

## 추가 자료 수집 상태

10만 편 분석 완료 상태가 아닙니다. collection-status.json에 데이터 선별·본문 확보·전문 검토·엄격한 완료 수를 구분했습니다. 캡슐에는 검토한 공개 본문에서 작성한 짧은 요약만 반영했습니다. Instagram 이미지는 미분석이며 Threads는 지정 본문만 읽었습니다.
