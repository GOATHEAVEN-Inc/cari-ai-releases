# 모아워크 (가상 사례) IR 패키지 설계

모아워크 (합성 기능 검증용 가상 사례) · 2026-09-07

PDF 4장, 편집용 HWPX·PPTX, 사실표와 검토 기록입니다. 추가 확인 3건, 자동 경고 1건입니다. 투자 성공이나 제출 승인을 뜻하지 않습니다.

## Figma에서 편집

압축을 풀고 Figma 데스크톱의 Plugins → Development → Import plugin from manifest에서 figma/manifest.json을 선택한 뒤 실행하세요. Freesentation 또는 Noto Sans KR Regular 글꼴이 필요합니다. 새 페이지에 편집 가능한 텍스트·도형 프레임을 만들며 외부 전송은 없습니다. 글꼴 대체 시 줄바꿈을 확인하고 Figma에서 저장하세요. 이 ZIP은 네이티브 .fig 파일이 아닙니다.

## 검토

원자료 진위·투자 적합성·문장 자연스러움·전체 렌더·한컴/PowerPoint/Figma에서의 편집은 별도 검토가 필요합니다. PDF 아래 출처 ID의 실제 위치와 정의는 evidence-ledger.json과 HWPX 부록에 있습니다. HWPX는 HWP 바이너리와 다르며 공고 원본 양식을 채운 파일이 아닙니다. 페이지 출처·실적/전망/가정·미확인 표시를 삭제하지 마세요.
