# 정부지원사업계획서 전문가 캡슐

등록 ID: brain_government_grant_kr

비R&D 창업·사업화·지역·마케팅·판로 계획서의 공고 분석, 근거 기반 작성, 예산·일정·증빙 검수를 위한 CARI 캡슐입니다.

- capsule.json: 전문 지침, 루브릭, 실제 수집/분석 수, 런타임 계약
- knowledge.json: 실제 채팅 검색에 연결된 171개 지식
- sources.json: 원출처·읽은 범위·제외 자료. 개인정보 원문과 전체 자막 없음
- official-playbook.md / accepted-patterns.md / knowhow-playbook.md: 출처군별 작성 원칙

사용 예: '첨부한 2026년 ○○ 사업 공고와 한글 양식을 먼저 분석하고, 제공한 기업 정보로 사업계획서를 HWPX로 작성해줘. 확인되지 않은 실적은 만들지 말고 별도 질문해줘.' 또는 '단가·수량·횟수로 사업비를 계산하고 정부지원금·현금·현물 및 합계를 엑셀 수식으로 만들어줘.'

DOCX·XLSX·HWPX 생성은 CARI 런타임과 모델 연결이 필요합니다. 이 ZIP은 독립 모델이나 가중치 학습 파일이 아닙니다. 새 HWPX 생성과 임의 원본 한글 양식의 완전한 서식 보존, DOCX 파일과 실제 구글 독스 등록을 구분합니다. 실제 공고의 서식/자격/서명/최종 제출 확인은 필요합니다. 합격이나 공식 심사점수를 보장하지 않습니다.

government-grant-plan-capsule-v1.png: 이 캡슐의 투명 PNG 이미지. capsule.json의 artwork에 파일 해시와 공개 경로가 기록되어 있습니다.
